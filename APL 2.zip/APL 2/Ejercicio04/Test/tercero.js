un codigo
dos codigos //un comentario
tres codigos /*dos comentarios*/
cuatro codigos
