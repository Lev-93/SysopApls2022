class holaMundo
{
    // Tu programa comienza con una llamada a main().
    // Imprime "Hola Mundo" a la ventana de la terminal.
    /* Otro comentario multilinea*/
    public static void main(String args[])
    {
        System.out.println("Hola Mundo");
    }
}