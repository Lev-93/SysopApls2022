#include <stdio.h>
int main() {
   int var = 1; /*Comentario
   multi
   linea*/
   printf("Hello, World!");
   return 0;
}