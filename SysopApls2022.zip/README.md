# SysopApls2022
Apls 1 2 y 3 de la materia sistemas operativos
